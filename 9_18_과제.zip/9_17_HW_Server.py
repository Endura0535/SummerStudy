__author__ = 'USER'

import socket
import thread
import threading

HOST = '127.0.0.1'
PORT = 12345

TS = socket.socket()

TS.bind((HOST, PORT))
TS.listen(1)
CS, address = TS.accept()

while True:
    data = CS.recv(1024)
    print(data)
    S = raw_input()
    CS.send(str(S))
