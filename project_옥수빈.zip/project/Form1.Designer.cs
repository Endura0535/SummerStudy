﻿namespace project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.character = new System.Windows.Forms.PictureBox();
            this.ball = new System.Windows.Forms.PictureBox();
            this.map = new System.Windows.Forms.PictureBox();
            this.reset = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.character)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.map)).BeginInit();
            this.SuspendLayout();
            // 
            // character
            // 
            this.character.Image = global::project.Properties.Resources.character;
            this.character.Location = new System.Drawing.Point(585, 357);
            this.character.Name = "character";
            this.character.Size = new System.Drawing.Size(60, 60);
            this.character.TabIndex = 4;
            this.character.TabStop = false;
            // 
            // ball
            // 
            this.ball.Image = global::project.Properties.Resources.Ball;
            this.ball.Location = new System.Drawing.Point(597, 291);
            this.ball.Name = "ball";
            this.ball.Size = new System.Drawing.Size(60, 60);
            this.ball.TabIndex = 3;
            this.ball.TabStop = false;
            this.ball.Click += new System.EventHandler(this.ball_Click);
            // 
            // map
            // 
            this.map.Image = global::project.Properties.Resources.map;
            this.map.Location = new System.Drawing.Point(380, 100);
            this.map.Name = "map";
            this.map.Size = new System.Drawing.Size(380, 336);
            this.map.TabIndex = 2;
            this.map.TabStop = false;
            // 
            // reset
            // 
            this.reset.AutoSize = true;
            this.reset.Location = new System.Drawing.Point(1019, 100);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(39, 15);
            this.reset.TabIndex = 5;
            this.reset.Text = "reset";
            this.reset.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gulim", 40F);
            this.label1.Location = new System.Drawing.Point(483, 230);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 67);
            this.label1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 687);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.character);
            this.Controls.Add(this.ball);
            this.Controls.Add(this.map);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.character)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.map)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox map;
        private System.Windows.Forms.PictureBox ball;
        public System.Windows.Forms.PictureBox character;
        private System.Windows.Forms.Label reset;
        private System.Windows.Forms.Label label1;
    }
}

