__author__ = 'USER'

import socket
import thread
import threading

HOST = '127.0.0.1'
PORT = 12345

TS = socket.socket()

TS.bind((HOST, PORT))
TS.listen(1)
CS, address = TS.accept()

def chat(CS):
    while True:
        data = CS.recv(1024)
        print(data)

def chat1(CS):
    while True:
        S = raw_input()
        CS.send(str(S))

th = threading.Thread(target=chat, args=(CS, ))
th.start()

th = threading.Thread(target=chat1, args=(CS, ))
th.start()