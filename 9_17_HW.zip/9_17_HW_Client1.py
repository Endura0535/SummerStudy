__author__ = 'USER'

import socket
import thread
import threading

HOST = '127.0.0.1'
PORT = 12345
ADDR = (HOST, PORT)


CS = socket.socket()
CS.connect(ADDR)

while True:
    C = raw_input()
    CS.send(str(C))
    data = CS.recv(1024)
    print data
