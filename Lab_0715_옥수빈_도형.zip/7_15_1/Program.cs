﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _7_15_1
{
    class TwoDim
    {
        public double girth;
        public double area;
    }

    class Triangle : TwoDim
    {
        public Triangle (int m_r)
        {
            girth = m_r * 3;
            area = Math.Pow(3, 0.5) / 4.0 * m_r * m_r;
        }
    }

    class Square : TwoDim
    {
        public Square(int m_r)
        {
            girth = m_r * 4;
            area = m_r * m_r;
        }
    }

    class Circle : TwoDim
    {
        public Circle(int m_r)
        {
            girth = m_r * 2 * 3.14;
            area = m_r * m_r * 3.14;
        }
    }

    class ThreeDim
    {
        public double SurfaceArea;
        public double volume;
    }

    class Cube : ThreeDim
    {
        public Cube(int m_r)
        {
            SurfaceArea = 6 * m_r * m_r; 
            volume = m_r * m_r * m_r;
        }

        List<Cube> cub = new List<Cube>();
    }

    class Sphere : ThreeDim
    {
        public Sphere(int m_r)
        {
            SurfaceArea = 4 * 3.14 * m_r * m_r;
            volume = 4.0 / 3 * 3.14 * m_r * m_r * m_r;
        }

        List<Sphere> sph = new List<Sphere>();
    }

    class Program
    {
        static void Main(string[] args)
        {
                List<Triangle> tri = new List<Triangle>();
                List<Square> squ = new List<Square>();
                List<Circle> cir = new List<Circle>();
                List<Cube> cub = new List<Cube>();
                List<Sphere> sph = new List<Sphere>();
            while(true)
            {
                Console.WriteLine("Shape, r: ");
                string Sha = Console.ReadLine();
                int r = Convert.ToInt32(Console.ReadLine());
                Triangle ttt = new Triangle(r);
                Square sss = new Square(r);
                Circle ccc = new Circle(r);
                Cube ccu = new Cube(r);
                Sphere ssp = new Sphere(r);


                if(Sha == "triangle")
                {
                    int j = 0;

                    for(int i = 0; i < tri.Count; i++)
                    {
                        if (r*3 == tri[i].girth)
                        {
                            j++;
                        }
                    }
                     
                    if(j == 0)
                    {
                         TwoDim tr = new Triangle(r);
                         Console.WriteLine("둘레: " + tr.girth + " 넓이: " + tr.area);
                         ttt.girth = r*3;
                         tri.Add(ttt);
                    }

                    else
                    {
                        Console.WriteLine("Already Exist");
                    }
                   
                }
                else if (Sha == "square")
                {
                    int j = 0;

                    for (int i = 0; i < squ.Count; i++)
                    {
                        if (r * 4 == squ[i].girth)
                        {
                            j++;
                        }
                    }

                    if (j == 0)
                    {
                        TwoDim sh = new Square(r);
                        Console.WriteLine("둘레: " + sh.girth + " 넓이: " + sh.area);
                        sss.girth = r * 4;
                        squ.Add(sss);
                    }

                    else
                    {
                        Console.WriteLine("Already Exist");
                    }

                       }
                else if (Sha == "circle")
                {
                    int j = 0;

                    for (int i = 0; i < cir.Count; i++)
                    {
                        if (2 * 3.14 * r == cir[i].girth)
                        {
                            j++;
                        }
                    }

                    if (j == 0)
                    {
                        TwoDim ci = new Circle(r);
                        Console.WriteLine("둘레: " + ci.girth + " 넓이: " + ci.area);
                        ccc.girth = 2*r*3.14;
                        cir.Add(ccc);

                    }

                    else
                    {
                        Console.WriteLine("Already Exist");
                    }
               }
                else if (Sha == "cube")
                {
                    int j = 0;

                    for (int i = 0; i < cub.Count; i++)
                    {
                        if (r*r*6 == cub[i].SurfaceArea)
                        {
                            j++;
                        }
                    }

                    if (j == 0)
                    {
                        ThreeDim cu = new Cube(r);
                        Console.WriteLine("겉넓이: " + cu.SurfaceArea + "  부피: " + cu.volume);
                        ccu.SurfaceArea = r*r*6;
                        cub.Add(ccu);
                    }

                    else
                    {
                        Console.WriteLine("Already Exist");
                    }
                    
               }
                else if (Sha == "sphere")
                {
                    int j = 0;

                    for (int i = 0; i < sph.Count; i++)
                    {
                        if (r * r * 4 * 3.14 == sph[i].SurfaceArea)
                        {
                            j++;
                        }
                    }

                    if (j == 0)
                    {
                        ThreeDim sp = new Sphere(r);
                        Console.WriteLine("겉넓이: " + sp.SurfaceArea + "  부피: " + sp.volume);
                        ssp.SurfaceArea = r * r * 4 * 3.14;
                        sph.Add(ssp);
                    }

                    else
                    {
                        Console.WriteLine("Already Exist");
                    }
                }
            }
        }
    }
}
