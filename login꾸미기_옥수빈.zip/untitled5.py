#-*-coding:utf-8-*-
from flask import Flask, render_template, redirect, request, session
from flaskext.mysql import MySQL

mysql = MySQL()
app = Flask(__name__)
app.config['MYSQL_DATABASE_USER'] = 'serverstudy'
app.config['MYSQL_DATABASE_PASSWORD'] = 'serverstudy!@#'
app.config['MYSQL_DATABASE_DB'] = 'serverstudy'
app.config['MYSQL_DATABASE_HOST'] = 'data.khuhacker.com'
app.config['MYSQL_CHARSET'] = 'utf-8'
mysql.init_app(app)

app = Flask(__name__)

app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'

@app.route('/loginpage')
def loginpage():
    if session['logged_in']==True:
        return render_template('loginpage.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        if 'logged_in' in session.keys() and session['logged_in']==True:
            return render_template('log_fail.html')
        else:
            I_D = request.form['username']
            P_W = request.form['password']
            cur = mysql.connect().cursor()
            cur.execute("SELECT * FROM sb_log WHERE ID =%s and PW=%s",(I_D,P_W))
            datas = cur.fetchone()

            if datas:
                session['logged_in'] = True
                session['username'] = request.form['username']
                return render_template('login_success.html')
            else:
                return render_template('log_fail.html')
    elif request.method == 'GET':
        return render_template('login.html')

@app.route('/logout', methods=['POST','GET'])
def logout():
    if 'logged_in' in session.keys() and session['logged_in']==True:
        session['logged_in'] = False
        session.pop('username', None)
        return render_template('login_success.html')
    else:
        return render_template('log_fail.html')


@app.route('/')
def test():
    return render_template('loginpage.html')

if __name__ == '__main__':
    app.run()
