#-*-coding:utf-8-*-
from flask import Flask, render_template, redirect, request, session
from flaskext.mysql import MySQL

mysql = MySQL()
app = Flask(__name__)
app.config['MYSQL_DATABASE_USER'] = 'serverstudy'
app.config['MYSQL_DATABASE_PASSWORD'] = 'serverstudy!@#'
app.config['MYSQL_DATABASE_DB'] = 'serverstudy'
app.config['MYSQL_DATABASE_HOST'] = 'data.khuhacker.com'
app.config['MYSQL_CHARSET'] = 'utf-8'
mysql.init_app(app)

app = Flask(__name__)

app.secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'

@app.route('/loginpage')
def loginpage():
    if session['logged_in']==True:
        return render_template('loginpage.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        if session['logged_in']==True:
            return "There's already logged in user"
        else:
            I_D = request.form['username']
            P_W = request.form['password']
            cur = mysql.connect().cursor()
            cur.execute("SELECT * FROM sb_log WHERE ID =%s and PW=%s",(I_D,P_W))
            datas = cur.fetchone()

            if datas:
                session['logged_in'] = True
                session['username'] = request.form['username']
                return "Login success"
            else:
                return "Login failed"
    elif request.method == 'GET':
        return render_template('login.html')

@app.route('/logout', methods=['POST','GET'])
def logout():
    if session['logged_in']==True:
        session['logged_in'] = False
        session.pop('username', None)
        return "Logged out"
    else:
        return "There's not logged in user"


@app.route('/')
def test():
    return render_template('loginpage.html')

if __name__ == '__main__':
    app.run()
