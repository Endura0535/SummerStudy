#-*-coding:utf-8-*-
from flask import Flask, render_template, redirect, request
from flaskext.mysql import MySQL

mysql = MySQL()
app = Flask(__name__)
app.config['MYSQL_DATABASE_USER'] = 'serverstudy'
app.config['MYSQL_DATABASE_PASSWORD'] = 'serverstudy!@#'
app.config['MYSQL_DATABASE_DB'] = 'serverstudy'
app.config['MYSQL_DATABASE_HOST'] = 'data.khuhacker.com'
app.config['MYSQL_CHARSET'] = 'utf-8'
mysql.init_app(app)

@app.route('/guestbook')
def gusstbook():
    cur = mysql.connect().cursor()
    cur.execute("SELECT * FROM sb_guest")
    datas = cur.fetchall()

    return render_template("guestbook.html", datas=datas)

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        ID = request.form['ID']
        Content = request.form['Content']
        con = mysql.connect()
        cur = con.cursor()
        cur.execute("INSERT INTO sb_guest(username, comment) VALUES(%s, %s)",(ID, Content))
        con.commit()
        con.close()

        return redirect('/guestbook')

@app.route('/delete', methods=['POST'])
def delete():
    I_Number = request.form['D_Num']
    con = mysql.connect()
    cur = con.cursor()
    cur.execute("DELETE FROM sb_guest WHERE num = %s", (I_Number))
    con.commit()
    con.close()

    return redirect('/guestbook')

@app.route('/modify', methods=['POST'])
def modify():
    if request.method == 'POST':
        M_Num=request.form['M_Num']
        M_Content = request.form['M_Content']
        con = mysql.connect()
        cur = con.cursor()
        cur.execute("UPDATE sb_guest SET comment = %s  WHERE num = %s", (M_Content, M_Num))
        con.commit()
        con.close()

        return redirect('/guestbook')

@app.route('/')
def hello_world():
    return render_template('hello.html')

if __name__ == '__main__':
    app.run(debug=True)
